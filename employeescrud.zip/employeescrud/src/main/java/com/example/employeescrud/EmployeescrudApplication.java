package com.example.employeescrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeescrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeescrudApplication.class, args);
	}

}
